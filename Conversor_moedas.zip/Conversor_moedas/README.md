# Conversor de Moedas - Python com customtkinter

Este é um projeto simples em Python que implementa um conversor de moedas com interface gráfica usando a biblioteca **customtkinter**.

## Funcionalidades

- Seleção de moeda de origem e destino (Real, Dólar, Euro, Iene)
- Entrada de valor para conversão
- Exibição do resultado da conversão formatado com duas casas decimais
- Tratamento de erros para valores inválidos

## Tecnologias

- Python 3
- customtkinter

## Como usar

1. Certifique-se de ter o Python 3 instalado no seu sistema.

2. Instale a biblioteca **customtkinter** com o comando:
   ```bash
   pip install customtkinter
